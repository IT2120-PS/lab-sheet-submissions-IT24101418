setwd("//Users//sithijaransara//Desktop//Lab 06")
getwd()

#1).
#i. Binomial distribution
#ii.
1-pbinom(46,50,0.85,lower.tail=TRUE)

#2).
#i. Number of calls per hour
#ii. Poisson Distribution
#iii.
dpois(15,12)





