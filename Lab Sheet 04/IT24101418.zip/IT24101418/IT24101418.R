setwd("C:/Users/IT24101418/Desktop/PS Lab04")
getwd()

#1 Question (Importing dataset)
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")


#2 Qustion (identify variable type & scal of measurement)
str(branch_data)


#3 Question (Boxplot for sales)
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales")


#4 Question (Calculate the five number summary and IQR)
# Five number summary 
summary(branch_data$Advertising_X2)

# Calculate IQR
IQR(branch_data$Advertising_X2)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

outliers_advertising <- find_outliers(branch_data$Advertising_X2)
outliers_advertising

